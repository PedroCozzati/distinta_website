import { Component } from '@angular/core';

@Component({
  selector: 'app-forms',
  templateUrl: './forms.html',
  standalone: true
})
export class FormsComponent {}
