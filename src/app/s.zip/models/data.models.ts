export interface ScheduleItem {
  image: string;
  title: string;
  subtitle: string;
  day: string;
  time: string;
}

export interface Band {
  name: string;
  description: string;
  genre: string;
  image: string;
  instagram: string;
}

export interface MenuItem {
  name: string;
  description: string;
  price: string;
  image: string;
}

export interface EntertainmentItem {
  name: string;
  image: string;
}

export interface ScheduleEvent {
  day: string;
  title: string;
  description: string;
}
